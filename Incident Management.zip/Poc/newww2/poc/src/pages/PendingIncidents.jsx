// src/pages/PendingIncidents.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";

const API_BASE = "http://127.0.0.1:5000";

export default function PendingIncidents() {
  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/incidents/pending`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setRows(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error(e);
        setError("Failed to load pending incidents.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const openIncident = (row) => {
    localStorage.setItem("incident_id", row.incident_id);
    navigate(row.next_step || "/general-info");
  };

  const filteredRows = rows.filter((r) => {
    const q = search.toLowerCase();
    return (
      (r.incident_id || "").toLowerCase().includes(q) ||
      (r.title || "").toLowerCase().includes(q) ||
      (r.status || "").toLowerCase().includes(q)
    );
  });

  return (
    <>
      <Navbar disableTabs={true} />

      <style>{`
        .pi-page {
          max-width: 1100px;
          margin: 30px auto;
          padding: 0 16px;
        }

        /* top header row (NOT a card) */
        .pi-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 18px;
        }

        .pi-header h2 {
          margin: 0;
        }

        .pi-search {
          width: 420px;
          padding: 12px 16px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          font-size: 14px;
          background: #ffffff;
          outline: none;
        }

        /* ONLY the table is the card */
        .pi-card {
          background: #ffffff;
          box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
          border-radius: 12px;
          overflow: hidden;
        }

        .pi-card table {
          width: 100%;
          border-collapse: collapse;
        }

        .pi-card thead {
          background: #2563eb;
          color: #ffffff;
        }

        .pi-card th, .pi-card td {
          padding: 12px 14px;
          text-align: left;
          font-size: 14px;
        }

        .pi-card tbody tr:nth-child(even) {
          background: #f9fafb;
        }

        .pi-card tbody tr:hover {
          background: #eef2ff;
        }

        .pi-btn {
          padding: 7px 14px;
          border-radius: 8px;
          border: none;
          background-color: #2563eb;
          color: #ffffff;
          cursor: pointer;
          font-size: 13px;
          font-weight: 700;
        }

        .pi-btn:hover {
          background-color: #1d4ed8;
        }

        /* back button BELOW the card (not inside) */
        .pi-footer {
          margin-top: 18px;
        }

        .pi-back-btn {
          padding: 10px 18px;
          border-radius: 999px;
          border: none;
          background-color: #2563eb;
          color: #ffffff;
          font-weight: 700;
          cursor: pointer;
          box-shadow: 0 8px 18px rgba(37, 99, 235, 0.25);
        }

        .pi-back-btn:hover {
          background-color: #1d4ed8;
        }
      `}</style>

      <div className="pi-page">
        {/* header (outside any card) */}
        <div className="pi-header">
          <h2>Pending Incidents</h2>
          <input
            className="pi-search"
            placeholder="Search by Incident ID / Title / Status"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {loading && <p>Loading…</p>}
        {error && <p style={{ color: "red" }}>{error}</p>}
        {!loading && !filteredRows.length && !error && <p>No pending incidents 🎉</p>}

        {!!filteredRows.length && (
          <div className="pi-card">
            <table>
              <thead>
                <tr>
                  <th>Incident ID</th>
                  <th>Title</th>
                  <th>Created</th>
                  <th>Status</th>
                  <th>Next Step</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row) => (
                  <tr key={row.incident_id}>
                    <td>{row.incident_id}</td>
                    <td>{row.title || "—"}</td>
                    <td>{row.created_at ? new Date(row.created_at).toLocaleString() : "—"}</td>
                    <td>{row.status || "—"}</td>
                    <td>{row.next_step || "—"}</td>
                    <td>
                      <button className="pi-btn" onClick={() => openIncident(row)}>
                        Open
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* back button OUTSIDE card */}
        <div className="pi-footer">
          <button className="pi-back-btn" onClick={() => navigate("/dashboard")}>
            Back to Dashboard
          </button>
        </div>
      </div>
    </>
  );
}
