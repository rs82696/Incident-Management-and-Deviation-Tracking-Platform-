import { useNavigate } from "react-router-dom";
import { useState } from "react";
import "./LoginPage.css";
import loginImage from "../assets/LoginImage.jpg";

const LoginPage = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
  const hardcodedUsername = "poc";
  const hardcodedPassword = "poc@123";

  if (
    username === hardcodedUsername &&
    password === hardcodedPassword
  ) {
    navigate("/dashboard");
  } else {
    alert("Invalid username or password");
  }
};


return (
  <div className="login-container">
    <div className="login-wrapper">

      {/* LEFT SIDE IMAGE */}
      <div className="login-image">
        <img src={loginImage} alt="Login Illustration" />
      </div>

      {/* RIGHT SIDE LOGIN FORM */}
      <div className="login-box">
        <h2>Login</h2>

        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleLogin}>Login</button>
      </div>

    </div>
  </div>
);


};

export default LoginPage;
