// src/pages/RejectedIncidents.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";

const API_BASE = "http://127.0.0.1:5000";

export default function RejectedIncidents() {
  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  const [q, setQ] = useState(""); // ✅ search
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/incidents/rejected`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setRows(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error(e);
        setError("Failed to load rejected incidents.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);
  const openIncident = (row) => {
    localStorage.setItem("incident_id", row.incident_id);
    navigate("/general-info"); // rejected → fix from General Info
  };

  // ✅ filter like View Incidents
  const filteredRows = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return rows;

    return rows.filter((r) => {
      const hay = `${r.incident_id || ""} ${r.title || ""} REJECTED`.toLowerCase();
      return hay.includes(query);
    });
  }, [rows, q]);

  const styles = {
    pageWrap: { maxWidth: 1100, margin: "30px auto", padding: "0 16px" },

    headerRow: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 18,
    },

    searchInput: {
      width: 420,
      padding: "12px 16px",
      borderRadius: 12,
      border: "1px solid #d1d5db",
      outline: "none",
      fontSize: 14,
      background: "#fff",
    },

    card: {
      width: "100%",
      borderCollapse: "collapse",
      background: "#ffffff",
      boxShadow: "0 10px 30px rgba(15, 23, 42, 0.08)",
      borderRadius: 12,
      overflow: "hidden",
    },

    th: {
      padding: "12px 14px",
      textAlign: "left",
      fontSize: 13,
      borderBottom: "1px solid #e5e7eb",
      background: "#f3f4f6",
      color: "#111827",
      fontWeight: 700,
    },

    td: {
      padding: "12px 14px",
      fontSize: 14,
      borderBottom: "1px solid #f3f4f6",
      color: "#111827",
    },

    pill: {
      display: "inline-block",
      padding: "4px 10px",
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 700,
      background: "#dc2626",
      color: "#ffffff",
    },

    btn: {
      padding: "7px 14px",
      borderRadius: 8,
      border: "none",
      background: "#2563eb",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: 13,
      fontWeight: 700,
    },

    backBtn: {
      marginTop: 18,
      padding: "10px 18px",
      borderRadius: 999,
      border: "none",
      background: "#2563eb",
      color: "#ffffff",
      fontWeight: 700,
      cursor: "pointer",
      boxShadow: "0 8px 18px rgba(37, 99, 235, 0.25)",
    },
  };

  return (
    <>
      <Navbar disableTabs={true} />

      <div style={styles.pageWrap}>
        {/* ✅ title left, search right */}
        <div style={styles.headerRow}>
          <h2 style={{ margin: 0 }}>Rejected Incidents</h2>

          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by Incident ID / Title / Status"
            style={styles.searchInput}
          />
        </div>

        {loading && <p>Loading…</p>}
        {error && <p style={{ color: "red" }}>{error}</p>}
        {!loading && !filteredRows.length && !error && <p>No rejected incidents.</p>}

        {!!filteredRows.length && (
          <table style={styles.card}>
            <thead>
              <tr>
                <th style={styles.th}>Incident ID</th>
                <th style={styles.th}>Title</th>
                <th style={styles.th}>Created</th>
                <th style={styles.th}>Status</th>
                <th style={styles.th}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.map((row) => (
                <tr key={row.incident_id}>
                  <td style={styles.td}>{row.incident_id}</td>
                  <td style={styles.td}>{row.title || "—"}</td>
                  <td style={styles.td}>
                    {row.created_at ? new Date(row.created_at).toLocaleDateString() : "—"}
                  </td>
                  <td style={styles.td}>
                    <span style={styles.pill}>REJECTED</span>
                  </td>
                  <td style={styles.td}>
                    <button style={styles.btn} onClick={() => openIncident(row)}>
                      Open
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* ✅ back button bottom-left */}
        <button style={styles.backBtn} onClick={() => navigate("/dashboard")}>
          Back to Dashboard
        </button>
      </div>
    </>
  );
}
