import React from "react";
import { useNavigate } from "react-router-dom";
import "./Navbar.css";

export default function Navbar({ activeTab, disableTabs = false }) {
  const navigate = useNavigate();
  const incidentTitle = localStorage.getItem("incident_title") || "New Incident";

  const tabs = [
    { name: "General Information", path: "/general-info" },
    { name: "Deviation Information", path: "/deviation" },
    { name: "Preliminary Investigation", path: "/preliminary" },
    { name: "RCA", path: "/review" },
    { name: "CAPA", path: "/closure" },
    { name: "Evaluation Comments", path: "/comments" },
  ];
  const handleLogout = () => {
    // ✅ clear all session data
    localStorage.clear();

    // ✅ redirect to login & prevent back navigation
    navigate("/", { replace: true });
  };

  return (
    <>
      {/* HEADER */}
      <header className="top-bar">
        <div className="title-area">
          <h1 className="record-title">
            {incidentTitle}
          </h1>
          <div className="record-sub">Pending Data Review</div>
          <div className="record-sub">Created: 2025-11-06</div>
        </div>

        {/* ✅ LOGOUT BUTTON */}
        <button className="logout-btn" onClick={handleLogout}>
          Logout
        </button>
      </header>

      {/* TABS */}
      <nav className="tabs" role="tablist" aria-label="Deviation workflow steps">
        {tabs.map((tab, index) => {
          const isActive = activeTab === index;

          return (
            <button
              key={tab.name}
              type="button"
              onClick={() => !disableTabs && navigate(tab.path)}
              className={`tab ${isActive ? "active" : ""} ${
                disableTabs ? "disabled" : ""
              }`}
              disabled={disableTabs}
              role="tab"
              aria-selected={isActive}
            >
              {tab.name}
            </button>
          );
        })}
      </nav>
    </>
  );
}
